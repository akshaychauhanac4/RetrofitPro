package com.example.akshay.retrofitpro;

/**
 * Created by Akshay on 20-01-2018.
 */

class Repo {
}
